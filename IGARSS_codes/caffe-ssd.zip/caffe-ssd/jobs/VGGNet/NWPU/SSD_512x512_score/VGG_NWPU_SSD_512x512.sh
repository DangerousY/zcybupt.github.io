cd /root/caffe-ssd
./build/tools/caffe train \
--solver="models/VGGNet/NWPU/SSD_512x512_score/solver.prototxt" \
--weights="models/VGGNet/NWPU/SSD_512x512/VGG_NWPU_SSD_512x512_iter_3000.caffemodel" \
--gpu 0 2>&1 | tee jobs/VGGNet/NWPU/SSD_512x512_score/VGG_NWPU_SSD_512x512_test3000.log
